package com.rivaan.allen.allen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
